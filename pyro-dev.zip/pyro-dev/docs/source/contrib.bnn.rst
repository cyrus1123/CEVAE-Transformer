Bayesian Neural Networks
=========================

.. automodule:: pyro.contrib.bnn

HiddenLayer
-------------------------
.. automodule:: pyro.contrib.bnn.hidden_layer
    :members:
    :member-order: bysource
